package com.clubmgmt.clubmgmtstudentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClubMgmtStudentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
