package com.clubmgmt.clubmgmtstudentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClubMgmtStudentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClubMgmtStudentServiceApplication.class, args);
	}

}
